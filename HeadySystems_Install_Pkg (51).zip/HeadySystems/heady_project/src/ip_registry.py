# Stub for ip_registry
