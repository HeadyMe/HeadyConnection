# Stub for compute_throttle
