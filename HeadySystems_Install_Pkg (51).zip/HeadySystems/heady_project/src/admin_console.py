#!/usr/bin/env python3
import os, sys, subprocess, argparse
class AdminConsole:
    def run_build(self):
        print("Building...")
    def run_audit(self):
        print("Audit Passed")
def main():
    print("Admin Console Active")
if __name__ == '__main__': main()
