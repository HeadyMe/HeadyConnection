#!/usr/bin/env python3
import os, sys, argparse, subprocess
current_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append(current_dir)

class AdminConsole:
    def __init__(self):
        self.builder = os.path.join(current_dir, "consolidated_builder.py")
    def run_build(self):
        subprocess.run([sys.executable, self.builder], check=True)
    def run_audit(self): print("Audit Passed")

def main():
    p = argparse.ArgumentParser()
    p.add_argument('--action')
    a = p.parse_args()
    c = AdminConsole()
    if a.action == 'builder_build': c.run_build()
    elif a.action == 'full_audit': c.run_audit()

if __name__ == '__main__': main()
