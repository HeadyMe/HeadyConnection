#!/usr/bin/env python3
import os, sys, json, hashlib, datetime
current_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append(current_dir)

# Imports with fallbacks
try:
    from heady_archive import HeadyArchive
    class VerticalTemplate:
        @staticmethod
        def get_config(v): return {"protocol": v}
except ImportError:
    class HeadyArchive:
        def preserve(self, m, context_tags=None): return m
    class VerticalTemplate:
        @staticmethod
        def get_config(v): return {}

CONFIG_FILE = 'projects.json'
def mint_coin(d): return "hc_v1_" + hashlib.sha256(json.dumps(d, sort_keys=True).encode()).hexdigest()[:16]

def execute_build():
    print("Starting Build...")
    # Check for config in CWD or up one level
    if os.path.exists(CONFIG_FILE):
        cfg_path = CONFIG_FILE
    elif os.path.exists(os.path.join("..", CONFIG_FILE)):
        cfg_path = os.path.join("..", CONFIG_FILE)
    else:
        print("Config not found."); return

    with open(cfg_path, 'r') as f: conf = json.load(f)
    ws = conf.get('workspace', './heady-fleet')
    if not os.path.exists(ws): os.makedirs(ws)
    
    archivist = HeadyArchive()
    for p in conf.get('projects', []):
        slug = p['slug']
        p_dir = os.path.join(ws, slug)
        os.makedirs(p_dir, exist_ok=True)
        m = {"project": slug, "domain": p.get("apex_domain"), "gov": "Heady v12.1"}
        if "vertical" in p: m["vertical_config"] = VerticalTemplate.get_config(p["vertical"])
        m["heady_coin_pow"] = mint_coin(m)
        m = archivist.preserve(m, [slug, "v12"])
        with open(os.path.join(p_dir, "heady-manifest.json"), "w") as f:
            json.dump(m, f, indent=2)
    print("Build Complete")

if __name__ == "__main__":
    try:
        execute_build()
    except Exception as e:
        print(f"Build Error: {e}")
        sys.exit(1)
