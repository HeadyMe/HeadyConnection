# Heady Systems Delivery Manifest (v12.1 Final)

**Generated:** 2026-01-25T01:54:02.914313+00:00

## Artifacts
| Filename | Size (Bytes) | SHA256 Checksum |
| :--- | :--- | :--- |
| `HeadySystems_Install_Pkg.zip` | 22 | `8739c76e681f900923b900c9df0ef75cf421d39cabb54650c4b9ad19b6a76d85` |
| `heady_demo_kit.zip` | 12019 | `57393ca6f6e266688d235ac3fbf78b9c0d078b35aab4cc59400df65889ddbe63` |
