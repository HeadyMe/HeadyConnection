#!/usr/bin/env python3
class AISafetyGateway: pass
class RAAFabric: pass
