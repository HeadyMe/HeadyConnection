#!/usr/bin/env python3
import time, json
print(json.dumps({"event": "stream_start"}))
