#!/usr/bin/env python3
import random
class HeadyReflect:
    def __init__(self): pass
    def validate_intent(self, ctx): return True
