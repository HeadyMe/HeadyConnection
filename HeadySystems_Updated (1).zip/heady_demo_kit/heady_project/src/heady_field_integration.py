class IsobusAdapter: pass
