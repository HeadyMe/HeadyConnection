class HeadySymphony: pass
