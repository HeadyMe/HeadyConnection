#!/usr/bin/env python3
class VerticalTemplate:
    @staticmethod
    def get_config(v): return {"vertical": v}
