class IPRegistry: pass
