#!/usr/bin/env python3
class DataVault: pass
class TrustDomain: pass
class LegacyBridge: pass
