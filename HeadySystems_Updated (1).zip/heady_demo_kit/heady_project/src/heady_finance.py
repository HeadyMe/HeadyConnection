class HeadyCoin: pass
