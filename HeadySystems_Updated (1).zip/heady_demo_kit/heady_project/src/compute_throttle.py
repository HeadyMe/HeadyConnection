class HeadyComputeThrottle: pass
