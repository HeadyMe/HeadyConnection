# Stub for heady_verticals
