# Stub for heady_society
