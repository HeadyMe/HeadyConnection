# Stub for stream_generator
