class HeadyReflect:
    def validate_intent(self, i): return True
