class IPRegistry:
    def list_assets(self): return ['Patent 1', 'Patent 2']
