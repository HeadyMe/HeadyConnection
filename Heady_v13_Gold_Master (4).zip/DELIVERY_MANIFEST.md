# Final Delivery Manifest (Functional Demo)
**Date:** 2026-01-25T14:33:09.938207

- `HeadySystems_Install_Pkg.zip`: 11047 bytes, SHA256: `1a5339c8a25d93d48959e9e9b867eea6ed9c39fc849e1b68a9e13bd31725ce66`
- `heady_demo_kit.zip`: 12016 bytes, SHA256: `98630f7a25abbad4163ed14bb69e178f97eb1ce40dea41a4a8fd95ff2e609030`
