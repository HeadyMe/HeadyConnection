# Delivery Manifest
**Date:** 2026-01-25T12:53:56.576614

- `HeadySystems_Install_Pkg.zip`: 2974 bytes
  SHA256: `62c583cbe76bf17d98e8918a2894aaa1c74264a61f1585cf84a84a29a6eafb0d`

- `heady_demo_kit.zip`: 4179 bytes
  SHA256: `fd5ef4b932ee8b942ad7e6dc4edc7a6825d2b5e3fd911c108a56c4022e508223`

